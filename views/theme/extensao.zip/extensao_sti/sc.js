var inicio = new Date(),
  CTeReCaptcha = !0,
  grecaptcharesponse = null,
  ssltesteRes = "",
  ssltesteResCompleto = !1,
  ssltesteLocalRes = "",
  ssltesteLocalResCompleto = !1;
function QtdAdd(e) {
  e ? QtdGet() : createCookie("qtd", QtdGet() + 1, 365);
}
function custGet(e, a) {
  var t = document.getElementById("strings1"),
    o = document.getElementById("strings2");
  (t.value = e),
    (o.onclick = function () {
      a(o.value);
    }),
    t.click();
}
function QtdGet() {
  var e = getCookie("qtd");
  return (
    ("NaN" != e && "" != e && null != e) || createCookie("qtd", 0, 365),
    parseInt(getCookie("qtd"))
  );
}
function UsuarioIDGet() {
  return "" == getCookie("UsuarioID").trim()
    ? ((fIDUsuario = Math.round(1e9 * Math.random())),
      createCookie("UsuarioID", fIDUsuario, 365),
      fIDUsuario)
    : getCookie("UsuarioID");
}
var UsuarioID = UsuarioIDGet(),
  Servidor = "baixarxml.ashx?fsist=1",
  ChaveNum = function () {
    return strnumeros(ele("chave").value);
  },
  Sorteio = [];
function SorteioCriar() {
  Sorteio = [];
  for (var e = 0; e < Servidores.length; e++)
    if (null != Servidores[e])
      for (var a = 0; a < Servidores[e].prioridade; a++) Sorteio.push(e);
}
function ServidorInserir1() {
  for (var e = !1, a = 0; a < Servidores.length; a++)
    "Servidor 1" == Servidores[a].nome && (e = !0);
  0 == e &&
    Servidores.push({
      nome: "Servidor 1",
      url: "baixarxml.ashx?fsist=1",
      prioridade: 1,
    });
}
function ServidorVerifica(e) {
  new Ajax2().GET(
    e.url + "&t=teste&r=" + Math.round(1e9 * Math.random()),
    function (a) {
      a.indexOf("OK") > -1
        ? (e.funcionando = !0)
        : ((e.funcionando = !1), (e.prioridade = 0), ServidorInserir1()),
        SorteioCriar();
    }
  );
}
function ServidoresVerificar() {
  for (var e = 0; e < Servidores.length; e++)
    null != Servidores[e] &&
      Servidores[e].prioridade > 0 &&
      "Servidor 1" != Servidores[e].nome &&
      ServidorVerifica(Servidores[e]);
}
function MyRandom(e, a) {
  return (
    (total = -1 * e + a),
    Math.round((total / 100) * (100 * Math.random()) - -1 * e)
  );
}
function Sorteando() {
  var e = MyRandom(0, Sorteio.length - 1),
    a = Servidores[Sorteio[e]];
  Servidor = a.url;
}
function opcao(e, a) {
  (ele("nfe").className = "opcao"),
    (ele("cte").className = "opcao"),
    (e.className = "opcao opcao-marcado"),
    TipoNFeIs() || 1 == CTeReCaptcha
      ? ((ele("tdCaptcha").style.display = "none"),
        (ele("chave").style.maxWidth = "100%"),
        (ele("chave").style.fontSize = "20px"),
        (ele("chave").style.marginBottom = "5px"),
        (ele("tabMeio").style.marginTop = "10px"),
        (ele("trCaptcha1").style.display = "none"),
        (ele("trCaptcha2").style.display = "none"),
        (ele("butbaixar").style.display = "none"),
        BaixarCaptcha(),
        (ele("DivDivExtensao").style.display = "block"),
        ele("chave").focus())
      : ((ele("DivDivExtensao").style.display = "none"),
        (ele("tdCaptcha").style.display = "table-cell"),
        (ele("chave").style.maxWidth = "337px"),
        (ele("chave").style.fontSize = "13.3333px"),
        (ele("chave").style.marginTop = ""),
        (ele("tabMeio").style.marginTop = "auto"),
        (ele("trCaptcha1").style.display = "table-row"),
        (ele("trCaptcha2").style.display = "table-row"),
        (ele("butbaixar").style.display = "table-cell"),
        BaixarCaptcha(a));
}
function TipoNFeSet(e) {
  e ? ele("nfe").click() : ele("cte").click();
}
function TipoNFeIs() {
  return ele("nfe").className.indexOf("opcao-marcado") > -1;
}
function Tipo() {
  return null != ele("nfe")
    ? TipoNFeIs()
      ? "&cte=0"
      : "&cte=1"
    : "&alternativo=1";
}
function URL() {
  return (
    null != ele("pub") && hash(),
    Servidor +
      "&UsuarioID=" +
      UsuarioID +
      Tipo() +
      "&pub=" +
      ("OK" == ssltesteLocalRes ? hash() : "") +
      "&com=" +
      ("OK" == ssltesteRes ? hash() : "")
  );
}
function loadMostra(e) {
  e
    ? (null != ele("load") && (ele("load").style.display = "block"),
      null != ele("loadf") && (ele("loadf").style.display = "block"))
    : (null != ele("load") && (ele("load").style.display = "none"),
      null != ele("loadf") && (ele("loadf").style.display = "none"));
}
function BaixarCaptchaFim() {
  loadMostra(!1),
    44 == strnumeros(ele("chave").value).length
      ? ele("captcha").focus()
      : ele("chave").focus();
}
function ContarCaracters() {
  ele("qtd").innerHTML =
    "Qtd.Caracteres: " + strnumeros(ele("chave").value).length;
}
function LeitorBarras(e) {
  1 != e.ctrlKey ||
    ("74" != e.which && "74" != e.which) ||
    (e.preventDefault(), ele("captcha").focus());
}
function inputAtivar(e, a) {
  var t = ele(e),
    o = t.style;
  1 == a
    ? ((t.readOnly = !1), (o.backgroundColor = "white"))
    : ((t.readOnly = !0), (o.backgroundColor = "#ebebe4"));
}
function Consultado(e) {
  null != ele("consultado") &&
    (e
      ? ((ele("consultado").style.display = "table"),
        inputAtivar("chave", !1),
        inputAtivar("captcha", !1),
        (ele("butbaixar").className = "but-destivado"),
        (ele("butconsulta").className = "but-destivado"))
      : ((ele("consultado").style.display = "none"),
        (ele("butVisualizar").style.display = "none"),
        (ele("butSemCert").style.display = "none"),
        (ele("butComCertificado").style.display = "none"),
        (ele("butImprimir").style.display = "none"),
        inputAtivar("chave", !0),
        inputAtivar("captcha", !0),
        (ele("butbaixar").className = ""),
        (ele("butconsulta").className = "")));
}
function NovaConsulta(e) {
  if (new Date() - inicio > 6e5)
    GAE("Grátis - Reiniciar", "OK"),
      (document.location = "/"),
      Consultado(!1),
      (ele("chave").value = ""),
      (ele("captcha").value = "");
  else {
    if (null != e && 0 == e.readOnly) return;
    Consultado(!1),
      (ele("chave").value = ""),
      (ele("captcha").value = ""),
      GAE("Grátis - Nova Consulta", "OK"),
      ContarCaracters(),
      0 == TipoNFeIs() ? BaixarCaptcha() : ele("chave").focus();
  }
}
function Verifica() {
  var e = ChaveNum(),
    a = ele("captcha").value;
  if ("" == e)
    return (
      MsgInf("É necessário digitar a chave.", function () {
        ele("chave").focus();
      }),
      !1
    );
  if (44 != e.length) {
    var t =
      "A chave informada tem " +
      e.length +
      " digitos, sendo que tem que ter 44 digitos.";
    return (
      e.length >= 88
        ? ((t = "Parece que você digitou mais de uma chave"),
          GAE("Grátis - Consulta", "Outros", "Várias chaves"))
        : (e.length > 44 &&
            GAE("Grátis - Consulta", "Outros", "Chave maior que 44"),
          e.length < 44 &&
            GAE("Grátis - Consulta", "Outros", "Chave menor que 44")),
      MsgInf(t, function () {
        ele("chave").focus();
      }),
      !1
    );
  }
  if (null != ele("nfe")) {
    if ("55" == e.substr(20, 2) && 0 == TipoNFeIs())
      return (
        MsgInf(
          "Essa chave e do tipo NFe. O sistema mudará para o modo NFe.",
          function () {
            TipoNFeSet(!0);
          }
        ),
        !1
      );
    if ("57" == e.substr(20, 2) && 1 == TipoNFeIs())
      return (
        MsgInf(
          "Essa chave e do tipo CTe. O sistema mudará para o modo CTe.",
          function () {
            TipoNFeSet(!1);
          }
        ),
        !1
      );
  }
  if ("57" != e.substr(20, 2) && "55" != e.substr(20, 2))
    return (
      MsgInf("Essa chave não é de NFe e também não é de CTe.", function () {
        ele("chave").focus();
      }),
      !1
    );
  if (
    0 ==
    (function (e) {
      for (
        var a, t = e.substr(0, 43), o = 0, r = [4, 3, 2, 9, 8, 7, 6, 5], i = 0;
        i < t.length;
        i++
      )
        o += r[i % 8] * parseInt(t.substr(i, 1));
      return (
        (0 == (a = o % 11) || 1 == a ? 0 : 11 - a) == parseInt(e.substr(43, 1))
      );
    })(e)
  )
    return (
      MsgInf(
        "Chave incorreta. Dígito verificador da Chave de Acesso inválido.",
        function () {
          ele("chave").focus();
        }
      ),
      !1
    );
  function o() {
    MsgInf(
      '<div style="text-align: justify;">Extensão não instalada ou não ativada, para você consegui efetuar a consulta é necessário instalar uma extensão. Assim será possível gerar o xml e o pdf no seu navegador. Abaixo você vai ter a opção da extensão para o Chrome ou o Firefox.</div><br/><a href="comandos.aspx?t=extensao">Extensão para o Chrome (Sem custo)</a><br/><br/><a href="https://addons.mozilla.org/pt-BR/firefox/addon/gerar-danfe-dacte/">Extensão para o Firefox (Sem custo)</a><br/><br/><a href="https://www.fsist.com.br/baixaremlote"><span>Download de XML em Lote (R$ 0,09 por chave)</span></a><br/><span style="font-size: 12px;">O custo é <b>R$ 0,09</b> por chave solicitada.</span><br/><span style="font-size: 12px;">Faça o teste com até 30 chaves sem custo.</span> <a style="font-size: 12px;" href="contato?de=Extensao">Dúvidas ?</a><br/><br/><div style="font-size: 12px">Depois que instalar a extensão você deve acessar o site novamente e efetuar a consulta.</div>',
      function () {}
    );
  }
  return TipoNFeIs() || CTeReCaptcha
    ? null != grecaptcharesponse ||
        ("none" == document.getElementById("DivExtensao").style.display
          ? (ele("divReCaptcha").style.display = "block")
          : o(),
        !1)
    : !(!TipoNFeIs() && !CTeReCaptcha) ||
        ("" == a
          ? (MsgInf(
              "É necessário digitar o código da imagem ao lado.",
              function () {
                ele("chave").focus();
              }
            ),
            !1)
          : !(a.length < 4) ||
            (MsgInf(
              "O código da imagem ao lado tem que ter 6 caracteres, favor digitar novamente.",
              function () {
                ele("chave").focus();
              }
            ),
            !1));
}
SorteioCriar();
var BaixarCaptchaIniciado = !1;
function BaixarCaptcha(e) {
  Sorteando(),
    Consultado(!1),
    0 != e && loadMostra(!0),
    0 == TipoNFeIs() &&
      0 == CTeReCaptcha &&
      (ele("imgcaptcha").src =
        URL() +
        "&t=captcha&chave=" +
        ChaveNum() +
        "&r=" +
        Math.round(1e9 * Math.random())),
    (ele("captcha").value = ""),
    BaixarCaptchaIniciado && GAE("Grátis - Atualizar Captcha", "OK"),
    (BaixarCaptchaIniciado = !0),
    TipoNFeIs(),
    loadMostra(!1);
}
function Consultar(e) {
  if (1 == Verifica()) {
    loadMostra(!0),
      hash(encodeURIComponent(grecaptcharesponse), ele("chave").value, e);
    var a = URL();
    grecaptcha.ready(function () {
      grecaptcha
        .execute("6LdMiaEUAAAAAFAkiK8dBv08u5jE6PHeAMa-qmyf", {
          action: "homepage",
        })
        .then(function (e) {
          new Ajax2().GET(
            a +
              "&t=consulta&v=2&chave=" +
              ChaveNum() +
              "&captcha=" +
              (TipoNFeIs() || CTeReCaptcha
                ? encodeURIComponent(grecaptcharesponse)
                : ele("captcha").value) +
              "&token=" +
              encodeURIComponent(e) +
              "&qtd=" +
              QtdGet(),
            function (e) {
              if (
                ((ele("butVisualizar").onclick = Visualizar),
                (ele("butImprimir").onclick = Imprimir),
                (ele("butSemCert").onclick = XMLSemCert),
                (ele("butComCertificado").onclick = XMLComCert),
                (ele("butSemCert").style.display = "table-cell"),
                (grecaptcharesponse = null),
                "OK" == (e = e.trim()))
              )
                loadMostra(!1),
                  TipoNFeIs()
                    ? 1 == TipoNFeIs() &&
                      (ele("ReCaptcha").src =
                        "https://www.nfe.fazenda.gov.br/portal/consultaRecaptcha.aspx?tipoConsulta=completa&tipoConteudo=XbSeqxE8pl8=")
                    : CTeReCaptcha
                    ? (ele("ReCaptcha").src =
                        "https://www.cte.fazenda.gov.br/portal/consultaRecaptcha.aspx?tipoConsulta=completa&tipoConteudo=mCK/KoCqru0=")
                    : ((ele("butVisualizar").style.display = "table-cell"),
                      (ele("butComCertificado").style.display = "table-cell")),
                  Consultado(!0),
                  GAE("Grátis - Consulta OK", "OK"),
                  QtdAdd(),
                  ChaveGravar(ChaveNum(), a),
                  null != ele("linksemcert") && ele("linksemcert").focus();
              else if (e.indexOf("certificado necessário") > -1)
                !(function (e) {
                  function t() {
                    return ele("comboPriEmpresaCNPJCPF").getAttribute(
                      "serialNumber"
                    );
                  }
                  function o() {
                    if (null != t() && "" != t()) {
                      var e = new Ajax2();
                      return (
                        e.PostAdd(
                          "url",
                          URL() + "&t=xmlcomcert&chave=" + ChaveNum()
                        ),
                        e.PostAdd("serialnumber", t()),
                        e.POST(
                          "http://localhost:5896/getComCertificado",
                          function (e) {
                            r(e);
                          }
                        ),
                        !0
                      );
                    }
                    return !1;
                  }
                  if ("3" == ele("strings3").value) {
                    function r(e) {
                      if (e.indexOf("ERRO=>JSON=>") > -1)
                        loadMostra(!1), MsgInf("Erro desconhecido." + e);
                      else if (
                        e.indexOf("Erro ao realizar download de NFe") > -1
                      )
                        loadMostra(!1),
                          MsgInf(
                            "Portal da fazenda: Erro ao realizar download"
                          );
                      else if (
                        e.indexOf(
                          "O CNPJ ou CPF do certificado não está autorizado"
                        ) > -1
                      )
                        loadMostra(!1),
                          MsgInf(
                            "Certificado digital não autorizado para essa nota, selecione o certificado digital correto.<br/>Para utilizar outro certificado digital é necessário finalizar o navegador e abrir novamente.",
                            function () {
                              null != t() &&
                                "" != t() &&
                                comboPriEmpresaClick(function () {
                                  loadMostra(!0), o();
                                });
                            }
                          );
                      else if (
                        e.indexOf("<title>403 - Forbidden: Access is denied") >
                        -1
                      )
                        loadMostra(!1),
                          MsgInf(
                            "Erro 403. Verifique se o certificado digital da sua empresa ou da pessoa física está instalado corretamente, caso ele seja token ou cartão verifique se ele está conectado ao computador. Verifique também se o seu certificado está na validade ou se ele foi revogado. Se necessário reinicie o seu navegador."
                          );
                      else if (
                        e.indexOf("Erro ao baixar o xml localmente") > -1
                      )
                        loadMostra(!1), MsgInf(e);
                      else if ("" != e) {
                        var a = new Ajax2();
                        alert(e);
                        a.PostAdd("xml", e),
                          a.POST(
                            URL() + "&t=uploadxml&chave=" + ChaveNum(),
                            function (e) {
                              loadMostra(!1),
                                "ok" == e
                                  ? (Consultado(!0),
                                    (ele("butSemCert").style.display = "none"),
                                    (ele("butComCertificado").onclick =
                                      XMLSemCert))
                                  : e.indexOf("Erro ao validar o xml") > -1
                                  ? MsgInf(
                                      'O portal nacional da fazenda teve uma mudança que torna necessário atualizar várias partes do site fsist. Assim que for concluída a atualização, será avisado no site. <br/><br/>Você pode baixar o xml utilizando o portal nacional fazenda, segue o link <a href="https://www.nfe.fazenda.gov.br/portal/consultaRecaptcha.aspx?tipoConsulta=resumo&tipoConteudo=7PhJ+gAVw2g=" target="_blank" >https://www.nfe.fazenda.gov.br/portal/<a><br/><br/>Caso precise converter o xml para pdf, você pode utilizar essa funcionalidade <a href="https://www.fsist.com.br/converter-xml-nfe-para-danfe">Converter XML para PDF</a><br/><br/>Caso precise saber as notas que foram emitidas para o seu CNPJ, você pode utilizar essa funcionalidade <a href="https://www.fsist.com.br/xmls-compartilhados">XMLs Compartilhados</a>'
                                    )
                                  : MsgInf("Erro: " + e);
                            }
                          );
                      } else
                        loadMostra(!1),
                          MsgInf(
                            '<h4>Erro ao realizar a consulta, <a href="' +
                              URL() +
                              "&t=xmlcomcert&chave=" +
                              ChaveNum() +
                              '">ver detalhes</a>. Ou teste o certificado <a href="https://www.fsist.com.br/cert/">clicando aqui</a>.</h4><ul><li>Em caso de erro 403, verifique o seu certificado digital.</li><li>Caso seu certificado digital seja A1, <a style="color: black" href="https://www.fsist.com.br/ajuda/artigos/instalar-certificado-digital-a1/">instale</a> o certificado na forma padrão do windows.</li><li>Caso o seu certificado seja token ou cartão, remova ele do computador, finalize navegador, recoloque o certificado e tente novamente.</li><li>Em caso de erro <span style="font-size: 12px;font-weight: bold;">"O CNPJ ou CPF do certificado não está autorizado a fazer o download do documento"</span>, é necessário escolher um certificado cujo CNPJ ou CPF tenha vínculo com a nota desejada.</ul><h4>Para utilizar outro certificado digital é necessário finalizar o navegador e abrir novamente.</h4>'
                          ),
                          window.open(
                            URL() + "&t=xmlcomcert&chave=" + ChaveNum()
                          );
                    }
                    o(),
                      0 == o() &&
                        custGet(JSON.parse(e).link, function (e) {
                          r(e);
                        }),
                      (ele("ReCaptcha").src = ele("ReCaptcha").src),
                      GAE("Grátis - Consulta OK", "OK"),
                      QtdAdd(),
                      ChaveGravar(ChaveNum(), a);
                  } else
                    MsgInf(
                      'É necessário remover a versão antiga da extensão e instalar a última versão da extensão para o Chrome.<br/><a href="https://chrome.google.com/webstore/detail/gerar-danfedacte/fnalonmlenogoaknbeikifdbaokkhmjj">https://chrome.google.com/webstore/detail/gerar-danfedacte/fnalonmlenogoaknbeikifdbaokkhmjj</a>'
                    );
                })(e);
              else if ("Código da Imagem inválido. Tente novamente." == e)
                loadMostra(!1),
                  MsgInf(e, function () {
                    ele("captcha").focus(), BaixarCaptcha(!0);
                  }),
                  GAE("Grátis - Consulta", "Captcha Errado");
              else if (
                (loadMostra(!1),
                GAE("Grátis - Consulta", "Outros", e),
                e.indexOf("NF-e INEXISTENTE na base nacional") > -1 ||
                  e.indexOf("CT-e INEXISTENTE na base nacional") > -1 ||
                  e.indexOf("Erro ao consultar Nota Fiscal eletrônica") > -1 ||
                  e.indexOf(
                    "A consulta completa da NF-e fica disponível por até"
                  ) > -1)
              ) {
                var t = "";
                e.indexOf("NF-e INEXISTENTE na base nacional") > -1 ||
                e.indexOf(
                  "A consulta completa da NF-e fica disponível por até"
                ) > -1
                  ? (t =
                      'NF-e INEXISTENTE na base nacional, em caso de dúvida consulte diretamente no portal oficial nacional de NFe.<a href="#" onclick="window.open(\'https://www.nfe.fazenda.gov.br/portal/consultaRecaptcha.aspx?tipoConsulta=completa&tipoConteudo=XbSeqxE8pl8=&nfe=' +
                      ChaveNum() +
                      "');\">http://www.nfe.fazenda.gov.br/</a>")
                  : e.indexOf("CT-e INEXISTENTE na base nacional") > -1
                  ? (t =
                      'CT-e INEXISTENTE na base nacional, em caso de dúvida consulte diretamente no portal oficial nacional de CTe.<a href="#" onclick="window.open(\'https://www.cte.fazenda.gov.br/portal/consultaRecaptcha.aspx?tipoConsulta=completa&tipoConteudo=mCK/KoCqru0=&cte=' +
                      ChaveNum() +
                      "');\">http://www.cte.fazenda.gov.br/</a>")
                  : e.indexOf("Erro ao consultar Nota Fiscal eletrônica") >
                      -1 &&
                    ((t =
                      "O portal nacional da fazenda retornou um erro ao tentar consultar essa chave."),
                    "55" == ChaveNum().substr(20, 2) &&
                      (t +=
                        '</br></br>Será necessário aguardar o portal nacional da fazenda <a href="https://www.nfe.fazenda.gov.br/portal/consulta.aspx?tipoConsulta=completa&tipoConteudo=XbSeqxE8pl8=">www.nfe.fazenda.gov.br</a> normalizar para poder consultar essa chave novamente.'),
                    "57" == ChaveNum().substr(20, 2) &&
                      (t +=
                        '</br></br>Será necessário aguardar o portal nacional da fazenda <a href="https://www.cte.fazenda.gov.br/portal/consulta.aspx?tipoConsulta=completa&tipoConteudo=mCK/KoCqru0=">www.cte.fazenda.gov.br</a> normalizar para poder consultar essa chave novamente.')),
                  MsgInf(t, function () {
                    BaixarCaptcha(!0);
                  });
              } else
                MsgInf(e, function () {
                  BaixarCaptcha(!0);
                });
            }
          );
        });
    });
  }
}
function Visualizar() {
  window.open(URL() + "&t=visualizar&chave=" + ChaveNum()),
    GAE("Grátis - Consulta", "Consultada", "Visualizar Nota");
}
function Imprimir() {
  window.open(URL() + "&t=pdf&chave=" + ChaveNum()),
    GAE("Grátis - Consulta", "Consultada", "Imprimir");
}
function XMLSemCert() {
  (document.location = URL() + "&t=xmlsemcert&chave=" + ChaveNum()),
    GAE("Grátis - Consulta", "Consultada", "Download XML Sem Certificado");
}
function XMLComCert() {
  (document.location = URL() + "&t=xmlcomcert2&chave=" + ChaveNum()),
    GAE("Grátis - Consulta", "Consultada", "Download XML Com Certificado");
}
var _hash = "";
function hash(e, a) {
  try {
    return null != e
      ? (_hash = (function (e) {
          function a(e, a) {
            return (e << a) | (e >>> (32 - a));
          }
          function t(e, a) {
            var t, o, r, i, n;
            return (
              (r = 2147483648 & e),
              (i = 2147483648 & a),
              (n = (1073741823 & e) + (1073741823 & a)),
              (t = 1073741824 & e) & (o = 1073741824 & a)
                ? 2147483648 ^ n ^ r ^ i
                : t | o
                ? 1073741824 & n
                  ? 3221225472 ^ n ^ r ^ i
                  : 1073741824 ^ n ^ r ^ i
                : n ^ r ^ i
            );
          }
          function o(e, o, r, i, n, s, l) {
            return (
              (e = t(
                e,
                t(
                  t(
                    (function (e, a, t) {
                      return (e & a) | (~e & t);
                    })(o, r, i),
                    n
                  ),
                  l
                )
              )),
              t(a(e, s), o)
            );
          }
          function r(e, o, r, i, n, s, l) {
            return (
              (e = t(
                e,
                t(
                  t(
                    (function (e, a, t) {
                      return (e & t) | (a & ~t);
                    })(o, r, i),
                    n
                  ),
                  l
                )
              )),
              t(a(e, s), o)
            );
          }
          function i(e, o, r, i, n, s, l) {
            return (
              (e = t(
                e,
                t(
                  t(
                    (function (e, a, t) {
                      return e ^ a ^ t;
                    })(o, r, i),
                    n
                  ),
                  l
                )
              )),
              t(a(e, s), o)
            );
          }
          function n(e, o, r, i, n, s, l) {
            return (
              (e = t(
                e,
                t(
                  t(
                    (function (e, a, t) {
                      return a ^ (e | ~t);
                    })(o, r, i),
                    n
                  ),
                  l
                )
              )),
              t(a(e, s), o)
            );
          }
          function s(e) {
            var a,
              t = "",
              o = "";
            for (a = 0; a <= 3; a++)
              t += (o = "0" + ((e >>> (8 * a)) & 255).toString(16)).substr(
                o.length - 2,
                2
              );
            return t;
          }
          var l,
            c,
            u,
            d,
            f,
            p,
            m,
            v,
            h,
            C = Array();
          for (
            e = (function (e) {
              e = e.replace(/\r\n/g, "\n");
              for (var a = "", t = 0; t < e.length; t++) {
                var o = e.charCodeAt(t);
                o < 128
                  ? (a += String.fromCharCode(o))
                  : o > 127 && o < 2048
                  ? ((a += String.fromCharCode((o >> 6) | 192)),
                    (a += String.fromCharCode((63 & o) | 128)))
                  : ((a += String.fromCharCode((o >> 12) | 224)),
                    (a += String.fromCharCode(((o >> 6) & 63) | 128)),
                    (a += String.fromCharCode((63 & o) | 128)));
              }
              return a;
            })(e),
              C = (function (e) {
                for (
                  var a,
                    t = e.length,
                    o = t + 8,
                    r = 16 * ((o - (o % 64)) / 64 + 1),
                    i = Array(r - 1),
                    n = 0,
                    s = 0;
                  s < t;

                )
                  (n = (s % 4) * 8),
                    (i[(a = (s - (s % 4)) / 4)] =
                      i[a] | (e.charCodeAt(s) << n)),
                    s++;
                return (
                  (n = (s % 4) * 8),
                  (i[(a = (s - (s % 4)) / 4)] = i[a] | (128 << n)),
                  (i[r - 2] = t << 3),
                  (i[r - 1] = t >>> 29),
                  i
                );
              })(e),
              p = 1732584193,
              m = 4023233417,
              v = 2562383102,
              h = 271733878,
              l = 0;
            l < C.length;
            l += 16
          )
            (c = p),
              (u = m),
              (d = v),
              (f = h),
              (p = o(p, m, v, h, C[l + 0], 7, 3614090360)),
              (h = o(h, p, m, v, C[l + 1], 12, 3905402710)),
              (v = o(v, h, p, m, C[l + 2], 17, 606105819)),
              (m = o(m, v, h, p, C[l + 3], 22, 3250441966)),
              (p = o(p, m, v, h, C[l + 4], 7, 4118548399)),
              (h = o(h, p, m, v, C[l + 5], 12, 1200080426)),
              (v = o(v, h, p, m, C[l + 6], 17, 2821735955)),
              (m = o(m, v, h, p, C[l + 7], 22, 4249261313)),
              (p = o(p, m, v, h, C[l + 8], 7, 1770035416)),
              (h = o(h, p, m, v, C[l + 9], 12, 2336552879)),
              (v = o(v, h, p, m, C[l + 10], 17, 4294925233)),
              (m = o(m, v, h, p, C[l + 11], 22, 2304563134)),
              (p = o(p, m, v, h, C[l + 12], 7, 1804603682)),
              (h = o(h, p, m, v, C[l + 13], 12, 4254626195)),
              (v = o(v, h, p, m, C[l + 14], 17, 2792965006)),
              (p = r(
                p,
                (m = o(m, v, h, p, C[l + 15], 22, 1236535329)),
                v,
                h,
                C[l + 1],
                5,
                4129170786
              )),
              (h = r(h, p, m, v, C[l + 6], 9, 3225465664)),
              (v = r(v, h, p, m, C[l + 11], 14, 643717713)),
              (m = r(m, v, h, p, C[l + 0], 20, 3921069994)),
              (p = r(p, m, v, h, C[l + 5], 5, 3593408605)),
              (h = r(h, p, m, v, C[l + 10], 9, 38016083)),
              (v = r(v, h, p, m, C[l + 15], 14, 3634488961)),
              (m = r(m, v, h, p, C[l + 4], 20, 3889429448)),
              (p = r(p, m, v, h, C[l + 9], 5, 568446438)),
              (h = r(h, p, m, v, C[l + 14], 9, 3275163606)),
              (v = r(v, h, p, m, C[l + 3], 14, 4107603335)),
              (m = r(m, v, h, p, C[l + 8], 20, 1163531501)),
              (p = r(p, m, v, h, C[l + 13], 5, 2850285829)),
              (h = r(h, p, m, v, C[l + 2], 9, 4243563512)),
              (v = r(v, h, p, m, C[l + 7], 14, 1735328473)),
              (p = i(
                p,
                (m = r(m, v, h, p, C[l + 12], 20, 2368359562)),
                v,
                h,
                C[l + 5],
                4,
                4294588738
              )),
              (h = i(h, p, m, v, C[l + 8], 11, 2272392833)),
              (v = i(v, h, p, m, C[l + 11], 16, 1839030562)),
              (m = i(m, v, h, p, C[l + 14], 23, 4259657740)),
              (p = i(p, m, v, h, C[l + 1], 4, 2763975236)),
              (h = i(h, p, m, v, C[l + 4], 11, 1272893353)),
              (v = i(v, h, p, m, C[l + 7], 16, 4139469664)),
              (m = i(m, v, h, p, C[l + 10], 23, 3200236656)),
              (p = i(p, m, v, h, C[l + 13], 4, 681279174)),
              (h = i(h, p, m, v, C[l + 0], 11, 3936430074)),
              (v = i(v, h, p, m, C[l + 3], 16, 3572445317)),
              (m = i(m, v, h, p, C[l + 6], 23, 76029189)),
              (p = i(p, m, v, h, C[l + 9], 4, 3654602809)),
              (h = i(h, p, m, v, C[l + 12], 11, 3873151461)),
              (v = i(v, h, p, m, C[l + 15], 16, 530742520)),
              (p = n(
                p,
                (m = i(m, v, h, p, C[l + 2], 23, 3299628645)),
                v,
                h,
                C[l + 0],
                6,
                4096336452
              )),
              (h = n(h, p, m, v, C[l + 7], 10, 1126891415)),
              (v = n(v, h, p, m, C[l + 14], 15, 2878612391)),
              (m = n(m, v, h, p, C[l + 5], 21, 4237533241)),
              (p = n(p, m, v, h, C[l + 12], 6, 1700485571)),
              (h = n(h, p, m, v, C[l + 3], 10, 2399980690)),
              (v = n(v, h, p, m, C[l + 10], 15, 4293915773)),
              (m = n(m, v, h, p, C[l + 1], 21, 2240044497)),
              (p = n(p, m, v, h, C[l + 8], 6, 1873313359)),
              (h = n(h, p, m, v, C[l + 15], 10, 4264355552)),
              (v = n(v, h, p, m, C[l + 6], 15, 2734768916)),
              (m = n(m, v, h, p, C[l + 13], 21, 1309151649)),
              (p = n(p, m, v, h, C[l + 4], 6, 4149444226)),
              (h = n(h, p, m, v, C[l + 11], 10, 3174756917)),
              (v = n(v, h, p, m, C[l + 2], 15, 718787259)),
              (m = n(m, v, h, p, C[l + 9], 21, 3951481745)),
              (p = t(p, c)),
              (m = t(m, u)),
              (v = t(v, d)),
              (h = t(h, f));
          return (s(p) + s(m) + s(v) + s(h)).toLowerCase();
        })(e + a + "true"))
      : _hash;
  } catch (e) {
    return "";
  }
}
function MostrarCTe() {
  (ele("DivConsulta").style.display = "block"),
    (ele("divtitulo").style.display = "block"),
    opcao(ele("cte"));
}
function ssltesteRegistrar() {
  ssltesteResCompleto &&
    ssltesteLocalResCompleto &&
    new Ajax2().GET(
      "sslteste.ashx?ssllocal=" +
        ("OK" == ssltesteLocalRes ? "OK" : "none") +
        "&sslexterno=" +
        ("OK" == ssltesteRes ? "OK" : "none") +
        "&iduser=" +
        UsuarioIDGet(),
      function (e) {}
    );
}
function sslteste() {
  function e() {
    new Ajax2().GET("https://sslteste2.fsist.com.br", function (e) {
      (ssltesteRes = e), (ssltesteResCompleto = !0), ssltesteRegistrar();
    });
  }
  try {
    new Ajax2().GET("https://sslteste2.fsist.com.br", function (a) {
      "OK" == a
        ? ((ssltesteRes = a), (ssltesteResCompleto = !0), ssltesteRegistrar())
        : e();
    });
  } catch (a) {
    e();
  }
}
function ssltesteLocal() {
  new Ajax2().GET("sslteste.ashx", function (e) {
    (ssltesteLocalRes = e),
      (ssltesteLocalResCompleto = !0),
      ssltesteRegistrar();
  });
}
window.addEventListener("message", function (e) {
  "sair" == e.data.cmd && (ele("divReCaptcha").style.display = "none"),
    "completo" == e.data.cmd &&
      "none" != ele("divReCaptcha").style.display &&
      ((ele("divReCaptcha").style.display = "none"),
      "" != e.data.value && ((grecaptcharesponse = e.data.value), Consultar()));
}),
  null != ele("imgcaptcha") &&
    (imgcaptcha.addEventListener("load", BaixarCaptchaFim),
    imgcaptcha.addEventListener("error", function () {
      ServidorInserir1();
    }));
var Empresas = [];
function comboPriEmpresaClick(e) {
  var a = Empresas.filter(function (e) {
      return 1 == e.ICPBrasil;
    }).sort(function (e, a) {
      return e.nome < a.nome ? -1 : e.nome > a.nome ? 1 : 0;
    }),
    t = document.createElement("table");
  t.className = "tabEmpresas";
  for (var o = 0; o < a.length; o++) {
    var r = a[o];
    if (0 == r.Vencido) {
      var i = t.insertRow();
      1 == r.Vencido && ((i.style.color = "red"), (i.title = "Vencido"));
      var n = i.insertCell();
      (n.innerHTML =
        '<input readonly="true" type="text" style="font: inherit; width: 100%;border: none; background-color: inherit;cursor: pointer;" value="' +
        r.nome +
        '" />'),
        (n.style.width = "100%");
      var s = i.insertCell();
      function l(a, t) {
        a.onclick = function () {
          MsgF(),
            0 == t.Vencido
              ? ((ele("comboPriEmpresaNome").value = t.nome),
                (ele("comboPriEmpresaUF").innerHTML =
                  null != t.uf ? "[" + t.uf + "]" : ""),
                (ele("comboPriEmpresaCNPJCPF").innerHTML = t.cnpjcpf),
                ele("comboPriEmpresaCNPJCPF").setAttribute(
                  "serialNumber",
                  t.serialNumber
                ),
                null != e && e())
              : MsgInf(
                  "Certificado vencido em " + t.datafinal + "<br/>" + t.nome
                );
        };
      }
      null != r.uf && (s.innerHTML = "[" + r.uf + "]"),
        (i.insertCell().innerHTML = r.cnpjcpf),
        l(i, r);
    }
  }
  var c = document.createElement("div");
  c.innerHTML =
    '<h3 style="margin-top: 5px; text-align: center">Certificados Digitais (ICP-Brasil)</h3>';
  var u = document.createElement("div");
  u.appendChild(t),
    (u.style.overflow = "auto"),
    (u.style.maxHeight = "300px"),
    c.appendChild(u);
  var d = document.createElement("button");
  (d.onclick = function () {
    MsgF();
  }),
    (d.innerHTML = "SAIR"),
    (d.className = "but4");
  var f = document.createElement("button");
  (f.onclick = function () {
    MsgF(),
      (ele("comboPriEmpresaNome").value = "SELECIONE O CERTIFICADO DIGITAL"),
      (ele("comboPriEmpresaUF").innerHTML = ""),
      (ele("comboPriEmpresaCNPJCPF").innerHTML = ""),
      ele("comboPriEmpresaCNPJCPF").setAttribute("serialNumber", "");
  }),
    (f.innerHTML = "Nenhuma"),
    (f.className = "but4"),
    MsgB(c, [f, d]);
}
function FSistAppGetCertificados() {
  new Ajax2().GET("http://localhost:5896/getCertificados", function (e) {
    e.indexOf("serialNumber") > -1 &&
      ((ele("comboPriEmpresa").style.display = "block"),
      (Empresas = JSON.parse(e)));
  });
}
function NovoPortalDaFazenda() {
  function e(e) {
    return decodeURIComponent(
      atob(e)
        .split("")
        .map(function (e) {
          return "%" + ("00" + e.charCodeAt(0).toString(16)).slice(-2);
        })
        .join("")
    );
  }
  (ele("butVisualizar").onclick = Visualizar),
    (ele("butImprimir").onclick = Imprimir),
    (ele("butSemCert").onclick = XMLSemCert),
    (ele("butComCertificado").onclick = XMLComCert);
  var a = ele("stringsFSistHtml");
  a.onclick = function () {
    var t = URL(),
      o = e(a.value),
      r = new Ajax2();
    r.PostAdd("htm", o),
      r.POST(t + "&t=uploadhtm&chave=" + ChaveNum(), function (e) {
        "ok" == e
          ? ((ele("consultado").style.display = "table"),
            (ele("butVisualizar").style.display = "table-cell"))
          : "oksem" == e
          ? ((ele("consultado").style.display = "table"),
            (ele("butVisualizar").style.display = "table-cell"),
            (ele("butSemCert").style.display = "table-cell"),
            (ele("butImprimir").style.display = "table-cell"),
            ChaveGravar(ChaveNum(), t))
          : (MsgF(), MsgInf(e));
      });
  };
  var t = ele("stringsFSistDados");
  (t.onclick = function () {
    var e = new Ajax2();
    e.PostAdd("dados", t.value),
      e.POST("consultaSetDados.aspx?chave=" + ChaveNum(), function (e) {});
  }),
    (ele("stringsFSistLink").onclick = function () {});
  var o = ele("stringsFSistXml");
  (o.onclick = function () {
    var a = e(o.value);
    if (a.indexOf("Erro 403, verifique o seu certificado digital.") > -1)
      MsgInf("Erro 403, verifique o seu certificado digital.");
    else if (
      a.indexOf(
        "É necessário utilizar certificado digital para acessar esta funcionalidade."
      ) > -1
    )
      MsgInf(
        "É necessário utilizar certificado digital para acessar esta funcionalidade. Reinicie o seu navegador completamente para selecionar o certificado digital."
      );
    else if (a.indexOf("O certificado digital utilizado é inválido.") > -1)
      MsgInf(
        "O certificado digital utilizado é inválido. Reinicie o seu navegador completamente para selecionar o certificado digital."
      );
    else {
      var t = URL(),
        r = new Ajax2();
      r.PostAdd("xml", a),
        r.POST(t + "&t=uploadxml&chave=" + ChaveNum(), function (e) {
          "ok" == e
            ? ((ele("consultado").style.display = "table"),
              (ele("butComCertificado").style.display = "table-cell"),
              (ele("butImprimir").style.display = "table-cell"),
              ChaveGravar(ChaveNum(), t))
            : e.indexOf("O CNPJ ou CPF do certificado não está") > -1
            ? (MsgF(),
              MsgInf(
                "Certificado digital não autorizado para essa nota, selecione o certificado digital correto.<br/>Para utilizar outro certificado digital é necessário finalizar o navegador e abrir novamente."
              ))
            : (MsgF(), MsgInf(e));
        });
    }
  }),
    (ele("butconsulta").onclick = function () {
      if ("" != ele("stringsFSistVersao").value) {
        if (
          (function () {
            function e(e) {
              for (
                var a = e.substr(0, 43),
                  t = 0,
                  o = 0,
                  r = [4, 3, 2, 9, 8, 7, 6, 5],
                  i = 0;
                i < a.length;
                i++
              )
                t += r[i % 8] * parseInt(a.substr(i, 1));
              return (
                (0 == (o = t % 11) || 1 == o ? 0 : 11 - o) ==
                parseInt(e.substr(43, 1))
              );
            }
            var a = ChaveNum();
            ele("captcha").value;
            if ("" == a)
              return (
                MsgInf("É necessário digitar a chave.", function () {
                  ele("chave").focus();
                }),
                !1
              );
            if (44 != a.length) {
              var t =
                "A chave informada tem " +
                a.length +
                " digitos, sendo que tem que ter 44 digitos.";
              return (
                a.length >= 88
                  ? ((t =
                      'Parece que você digitou mais de uma chave, caso deseje baixar múltiplas chaves de uma só vez é necessário utilizar o download em lote ou o Monitor de Notas se for dos últimos 90 dias.<br/><a href="usuario/cadastro.aspx?de=Mais_de_uma_chave">Clique aqui</a> para se cadastrar e fazer o teste.'),
                    GAE("Grátis - Consulta", "Outros", "Várias chaves"))
                  : (a.length > 44 &&
                      GAE("Grátis - Consulta", "Outros", "Chave maior que 44"),
                    a.length < 44 &&
                      GAE("Grátis - Consulta", "Outros", "Chave menor que 44")),
                MsgInf(t, function () {
                  ele("chave").focus();
                }),
                !1
              );
            }
            if ("57" != a.substr(20, 2) && "55" != a.substr(20, 2))
              return (
                MsgInf(
                  "Essa chave não é de NFe e também não é de CTe.",
                  function () {
                    ele("chave").focus();
                  }
                ),
                !1
              );
            if (0 == e(a))
              return (
                MsgInf(
                  "Chave incorreta. Dígito verificador da Chave de Acesso inválido.",
                  function () {
                    ele("chave").focus();
                  }
                ),
                !1
              );
            return !0;
          })()
        ) {
          var e = ele("stringsFSistChave"),
            a = ele("stringsFSistUrl");
          (e.value = strnumeros(ele("chave").value)),
            "55" == e.value.substr(20, 2)
              ? (a.value =
                  "https://www.nfe.fazenda.gov.br/portal/consultaRecaptcha.aspx?tipoConsulta=resumo&tipoConteudo=7PhJ+gAVw2g=")
              : "57" == e.value.substr(20, 2) &&
                (a.value =
                  "https://www.cte.fazenda.gov.br/portal/consultaRecaptcha.aspx?tipoConsulta=resumo&tipoConteudo=cktLvUUKqh0="),
            ele("stringsFSistClick").click();
        }
      } else
        MsgInf(
          '<div style="text-align: justify;">Extensão não instalada ou não ativada, para você consegui efetuar a consulta é necessário instalar uma extensão. Assim será possível gerar o xml e o pdf no seu navegador. Abaixo você vai ter a opção da extensão para o Chrome.</div><br/><a href="comandos.aspx?t=extensao">Extensão para o Chrome (Sem custo)</a><br/><br/><div style="font-size: 12px">Depois que instalar a extensão você deve acessar o site novamente e efetuar a consulta.</div>',
          function () {}
        );
    });
}
setTimeout(function () {
  ServidoresVerificar();
}, 500),
  setInterval(function () {
    ServidoresVerificar();
  }, 6e4),
  QtdAdd(!0),
  sslteste(),
  ssltest;
